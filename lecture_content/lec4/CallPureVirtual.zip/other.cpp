#include "pure_virtual.h"
void
A::g()
{
	f();
}
